**To delete a snapshot**

This example command deletes a snapshot with the snapshot ID of ``snap-1234abcd``.

Command::

  aws ec2 delete-snapshot --snapshot-id snap-1234abcd

Output::

   {
       "return": "true"
   }